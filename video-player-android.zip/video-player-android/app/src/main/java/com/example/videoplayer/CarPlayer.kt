package com.example.videoplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Surface
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/** Reproductor libVLC que dibuja el vídeo directamente en la superficie que da Android Auto. */
class CarPlayer(context: Context, val entries: List<PlaylistEntry>, private val onChange: () -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private val vlc = LibVLC(context, arrayListOf("--network-caching=2000"))
    private val player = MediaPlayer(vlc)
    private var surfaceAttached = false

    var current = -1
        private set
    /** Índices (de [entries]) entre los que se mueven anterior / siguiente. */
    var queue: List<Int> = emptyList()

    init {
        player.setEventListener { e ->
            main.post {
                when (e.type) {
                    MediaPlayer.Event.EndReached -> step(1)
                    MediaPlayer.Event.Playing, MediaPlayer.Event.Paused,
                    MediaPlayer.Event.EncounteredError -> onChange()
                }
            }
        }
    }

    fun attachSurface(surface: Surface, width: Int, height: Int) {
        val out = player.vlcVout
        if (surfaceAttached) out.detachViews()
        out.setVideoSurface(surface, null)
        out.attachViews()
        out.setWindowSize(width, height)
        player.aspectRatio = null
        player.scale = 0f
        surfaceAttached = true
    }

    fun detachSurface() {
        if (surfaceAttached) player.vlcVout.detachViews()
        surfaceAttached = false
    }

    fun play(index: Int) {
        val entry = entries.getOrNull(index) ?: return
        current = index
        val media = Media(vlc, Uri.parse(entry.url))
        player.media = media
        media.release()
        player.play()
        onChange()
    }

    fun step(delta: Int) {
        val q = queue.ifEmpty { entries.indices.toList() }
        if (q.isEmpty()) return
        val pos = q.indexOf(current)
        play(q[if (pos < 0) 0 else (pos + delta).mod(q.size)])
    }

    fun togglePlay() {
        if (player.media == null) step(1)
        else if (player.isPlaying) player.pause() else player.play()
    }

    fun title(): String? = entries.getOrNull(current)?.let { it.title ?: it.url }

    fun release() {
        main.removeCallbacksAndMessages(null)
        detachSurface()
        player.stop()
        player.release()
        vlc.release()
    }
}
