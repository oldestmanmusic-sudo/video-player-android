package com.example.videoplayer

import android.net.Uri
import java.net.URL

data class PlaylistEntry(val url: String, val title: String?)

/** Lee listas M3U/M3U8 (con o sin #EXTINF), PLS y listas de URLs en texto plano. */
object PlaylistParser {

    fun parse(text: String, base: Uri?): List<PlaylistEntry> {
        val clean = text.removePrefix("﻿")
        return if (clean.trimStart().startsWith("[playlist]", ignoreCase = true)) {
            parsePls(clean, base)
        } else {
            parseM3u(clean, base)
        }
    }

    private fun parseM3u(text: String, base: Uri?): List<PlaylistEntry> {
        val out = mutableListOf<PlaylistEntry>()
        var title: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.isEmpty() -> Unit
                line.startsWith("#EXTINF", ignoreCase = true) ->
                    title = line.substringAfter(',', "").trim().ifEmpty { null }
                line.startsWith("#") -> Unit
                else -> {
                    out += PlaylistEntry(resolve(line, base), title)
                    title = null
                }
            }
        }
        return out
    }

    private fun parsePls(text: String, base: Uri?): List<PlaylistEntry> {
        val files = sortedMapOf<Int, String>()
        val titles = mutableMapOf<Int, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1).trim()
            when {
                key.startsWith("File", ignoreCase = true) ->
                    key.substring(4).toIntOrNull()?.let { files[it] = value }
                key.startsWith("Title", ignoreCase = true) ->
                    key.substring(5).toIntOrNull()?.let { titles[it] = value }
            }
        }
        return files.map { (index, url) -> PlaylistEntry(resolve(url, base), titles[index]) }
    }

    private fun resolve(line: String, base: Uri?): String {
        if (Uri.parse(line).scheme != null || base == null) return line
        val scheme = base.scheme
        return if (scheme == "http" || scheme == "https") {
            URL(URL(base.toString()), line).toString()
        } else {
            line
        }
    }
}
