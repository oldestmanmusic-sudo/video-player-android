package com.example.videoplayer

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Lista de canales/entradas con filtro de búsqueda y resaltado del que está sonando. */
class ChannelAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.Holder>() {

    private var all: List<PlaylistEntry> = emptyList()
    private var shown: List<Int> = emptyList() // índices de `all` que pasan el filtro
    private var query = ""
    private var current = -1

    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

    fun submit(entries: List<PlaylistEntry>) {
        all = entries
        query = ""
        current = -1
        applyFilter()
    }

    fun filter(text: String) {
        query = text.trim()
        applyFilter()
    }

    fun setCurrent(index: Int) {
        current = index
        notifyDataSetChanged()
    }

    /** Posición visible de un índice de la lista completa, o -1 si está filtrado. */
    fun positionOf(index: Int): Int = shown.indexOf(index)

    private fun label(e: PlaylistEntry): String =
        e.title?.takeIf { it.isNotBlank() } ?: e.url.substringAfterLast('/').ifEmpty { e.url }

    /** Texto sobre el que busca el filtro: nombre y grupo. */
    private fun searchable(e: PlaylistEntry): String = label(e) + " " + (e.group ?: "")

    private fun applyFilter() {
        shown = all.indices.filter { query.isEmpty() || searchable(all[it]).contains(query, ignoreCase = true) }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false) as TextView
        return Holder(view)
    }

    override fun getItemCount() = shown.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val index = shown[position]
        val active = index == current
        val entry = all[index]
        holder.text.text = "${index + 1}.  ${label(entry)}" +
            (entry.group?.let { "\n$it" } ?: "")
        holder.text.setBackgroundColor(if (active) Color.parseColor("#3366B2FF") else Color.TRANSPARENT)
        holder.text.setTextColor(if (active) Color.parseColor("#66B2FF") else Color.WHITE)
        holder.text.setOnClickListener { onClick(index) }
    }
}
