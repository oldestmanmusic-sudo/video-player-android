package com.example.videoplayer

import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import com.google.android.apps.auto.sdk.CarActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * Pantalla de vídeo en Android Auto: lista de canales (Televisión / Radio) a la izquierda y
 * el vídeo con los controles a la derecha. El vídeo se pinta en un SurfaceView con libVLC.
 */
class CarVideoActivity : CarActivity() {

    private val main = Handler(Looper.getMainLooper())
    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null

    private var entries: List<PlaylistEntry> = emptyList()
    private var shown: List<Int> = emptyList()
    private var radioTab = false
    private var current = -1

    private lateinit var listView: ListView
    private lateinit var surface: SurfaceView
    private lateinit var status: TextView
    private lateinit var playPause: Button
    private lateinit var tabTv: Button
    private lateinit var tabRadio: Button
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setIgnoreConfigChanges(0xFFFFFFFF.toInt())
        carUiController.statusBarController.hideAppHeader()
        carUiController.menuController.hideMenuButton()

        entries = ChannelStore.load(this)
        radioTab = entries.none { !it.isRadio } && entries.any { it.isRadio }

        val engine = LibVLC(this, arrayListOf("--network-caching=2000"))
        vlc = engine
        player = MediaPlayer(engine).also { mp ->
            mp.setEventListener { e -> main.post { onPlayerEvent(e) } }
        }

        setContentView(buildUi())
        refreshList()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        player?.let {
            it.stop()
            it.vlcVout.detachViews()
            it.release()
        }
        vlc?.release()
        player = null
        vlc = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ interfaz

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 22f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor("#333333"))
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.BLACK)
        }

        // Columna izquierda: pestañas + lista
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabTv = button("TV") { selectTab(false) }
        tabRadio = button("Radio") { selectTab(true) }
        val tabParams = { LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) } }
        tabs.addView(tabTv, tabParams())
        tabs.addView(tabRadio, tabParams())
        left.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mutableListOf()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                val active = shown.getOrNull(position) == current
                v.setTextColor(if (active) Color.parseColor("#66B2FF") else Color.WHITE)
                v.setBackgroundColor(if (active) Color.parseColor("#3366B2FF") else Color.TRANSPARENT)
                v.textSize = 20f
                v.minHeight = dp(56)
                v.gravity = Gravity.CENTER_VERTICAL
                return v
            }
        }
        listView = ListView(this).apply {
            adapter = this@CarVideoActivity.adapter
            setBackgroundColor(Color.parseColor("#101010"))
            setOnItemClickListener { _, _, position, _ -> shown.getOrNull(position)?.let { play(it) } }
        }
        left.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // Columna derecha: vídeo + controles
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val videoBox = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                val out = player?.vlcVout ?: return
                if (!out.areViewsAttached()) {
                    out.setVideoView(surface)
                    out.attachViews()
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
                player?.vlcVout?.setWindowSize(w, h)
                player?.aspectRatio = null
                player?.scale = 0f
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                player?.vlcVout?.detachViews()
            }
        })
        videoBox.addView(surface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#99000000"))
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            text = "Elige un canal"
        }
        videoBox.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        right.addView(videoBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        playPause = button("▶") { togglePlay() }
        val ctrlParams = { LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) } }
        controls.addView(button("⏮") { step(-1) }, ctrlParams())
        controls.addView(playPause, ctrlParams())
        controls.addView(button("⏭") { step(1) }, ctrlParams())
        right.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 2f))

        return root
    }

    // ------------------------------------------------------------------ lógica

    private fun selectTab(radio: Boolean) {
        radioTab = radio
        refreshList()
    }

    private fun refreshList() {
        shown = entries.indices.filter { entries[it].isRadio == radioTab }
        adapter.clear()
        adapter.addAll(shown.map { i ->
            val e = entries[i]
            e.title?.takeIf { it.isNotBlank() } ?: e.url.substringAfterLast('/').ifEmpty { e.url }
        })
        adapter.notifyDataSetChanged()
        val tv = entries.count { !it.isRadio }
        val radio = entries.count { it.isRadio }
        tabTv.text = "TV ($tv)"
        tabRadio.text = "Radio ($radio)"
        tabTv.setBackgroundColor(Color.parseColor(if (!radioTab) "#3366B2FF" else "#333333"))
        tabRadio.setBackgroundColor(Color.parseColor(if (radioTab) "#3366B2FF" else "#333333"))
        if (entries.isEmpty()) status.text = "No hay canales: abre una lista en el móvil"
    }

    private fun play(index: Int) {
        val entry = entries.getOrNull(index) ?: return
        val mp = player ?: return
        val engine = vlc ?: return
        current = index
        adapter.notifyDataSetChanged()
        val media = Media(engine, Uri.parse(entry.url))
        mp.media = media
        media.release()
        mp.play()
        status.text = "⏳ " + (entry.title ?: entry.url)
    }

    private fun step(delta: Int) {
        if (shown.isEmpty()) return
        val pos = shown.indexOf(current)
        val next = if (pos < 0) 0 else (pos + delta).mod(shown.size)
        play(shown[next])
    }

    private fun togglePlay() {
        val mp = player ?: return
        if (mp.media == null) {
            shown.firstOrNull()?.let { play(it) }
        } else if (mp.isPlaying) mp.pause() else mp.play()
    }

    private fun onPlayerEvent(event: MediaPlayer.Event) {
        val title = entries.getOrNull(current)?.let { it.title ?: it.url } ?: ""
        when (event.type) {
            MediaPlayer.Event.Playing -> {
                status.text = title
                playPause.text = "⏸"
            }
            MediaPlayer.Event.Paused -> playPause.text = "▶"
            MediaPlayer.Event.EndReached -> step(1)
            MediaPlayer.Event.EncounteredError -> status.text = "No se puede reproducir: $title"
        }
    }
}
