package com.example.videoplayer

import com.google.android.apps.auto.sdk.CarActivity
import com.google.android.apps.auto.sdk.CarActivityService

/**
 * Entrada de la app en Android Auto con vídeo. Usa el SDK de proyección clásico (el mismo
 * que usa Fermata): Android Auto lanza [CarVideoActivity] en la pantalla del coche.
 * Requiere activar "Fuentes desconocidas" en los ajustes de desarrollador de Android Auto.
 */
class CarVideoService : CarActivityService() {
    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
    }

    override fun getCarActivity(): Class<out CarActivity> = CarVideoActivity::class.java

    companion object {
        /** Contexto real de nuestra app: el de la pantalla del coche puede apuntar a otro paquete. */
        @Volatile
        var appContext: android.content.Context? = null
    }
}
