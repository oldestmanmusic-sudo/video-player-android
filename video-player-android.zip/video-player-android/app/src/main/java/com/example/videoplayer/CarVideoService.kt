package com.example.videoplayer

import com.google.android.apps.auto.sdk.CarActivity
import com.google.android.apps.auto.sdk.CarActivityService

/** Entrada de la app en Android Auto (SDK de proyección, como Fermata): abre [CarVideoActivity]. */
class CarVideoService : CarActivityService() {
    override fun getCarActivity(): Class<out CarActivity> = CarVideoActivity::class.java
}
