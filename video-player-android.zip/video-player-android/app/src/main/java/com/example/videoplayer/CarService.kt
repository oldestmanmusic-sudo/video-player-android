package com.example.videoplayer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.MediaBrowserServiceCompat
import androidx.media.app.NotificationCompat.MediaStyle
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * Servicio de audio para Android Auto: muestra Radio y Televisión (solo el sonido) por grupos
 * y reproduce el canal elegido con libVLC. Android Auto no permite mostrar vídeo.
 */
class CarService : MediaBrowserServiceCompat() {

    private lateinit var session: MediaSessionCompat
    private lateinit var audioManager: AudioManager
    private val main = Handler(Looper.getMainLooper())

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var entries: List<PlaylistEntry> = emptyList()
    private var queue: List<Int> = emptyList()
    private var queuePos = -1
    private var focusRequest: AudioFocusRequest? = null
    private var resumeOnFocusGain = false

    private val callback = object : MediaSessionCompat.Callback() {
        override fun onPlayFromMediaId(mediaId: String?, extras: Bundle?) {
            val index = mediaId?.removePrefix("c:")?.toIntOrNull() ?: return
            val chosen = entries.getOrNull(index) ?: return
            val group = chosen.group ?: NO_GROUP
            queue = entries.indices.filter {
                entries[it].isRadio == chosen.isRadio && (entries[it].group ?: NO_GROUP) == group
            }
            queuePos = queue.indexOf(index)
            playCurrent()
        }

        override fun onPlay() {
            if (player?.media == null && queue.isNotEmpty()) playCurrent()
            else if (requestFocus()) player?.play()
        }

        override fun onPause() {
            player?.pause()
        }

        override fun onStop() {
            player?.stop()
            setState(PlaybackStateCompat.STATE_STOPPED)
            abandonFocus()
            stopForeground(STOP_FOREGROUND_REMOVE)
        }

        override fun onSkipToNext() = step(1)
        override fun onSkipToPrevious() = step(-1)
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        entries = ChannelStore.load(this)

        session = MediaSessionCompat(this, "VideoPlayerCar").apply {
            setCallback(callback)
            isActive = true
        }
        sessionToken = session.sessionToken
        setState(PlaybackStateCompat.STATE_NONE)

        val engine = LibVLC(this, arrayListOf("--network-caching=2000", "--no-video"))
        vlc = engine
        player = MediaPlayer(engine).also { mp ->
            mp.setEventListener { event -> main.post { onPlayerEvent(event) } }
        }
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onDestroy() {
        player?.release()
        vlc?.release()
        session.release()
        abandonFocus()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- navegación

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?) =
        BrowserRoot(ROOT, null)

    override fun onLoadChildren(
        parentId: String,
        result: Result<MutableList<MediaBrowserCompat.MediaItem>>
    ) {
        entries = ChannelStore.load(this)
        val items = mutableListOf<MediaBrowserCompat.MediaItem>()
        when {
            parentId == ROOT -> {
                val radio = entries.count { it.isRadio }
                val tv = entries.size - radio
                if (radio > 0) items += folder("k:radio", "Radio", "$radio emisoras")
                if (tv > 0) items += folder("k:tv", "Televisión (solo audio)", "$tv canales")
            }
            parentId.startsWith("k:") -> {
                val radio = parentId == "k:radio"
                entries.filter { it.isRadio == radio }
                    .groupBy { it.group ?: NO_GROUP }
                    .forEach { (group, list) ->
                        items += folder("g:${if (radio) "r" else "t"}:$group", group, "${list.size}")
                    }
            }
            parentId.startsWith("g:") -> {
                val radio = parentId[2] == 'r'
                val group = parentId.substring(4)
                entries.forEachIndexed { i, e ->
                    if (e.isRadio == radio && (e.group ?: NO_GROUP) == group) items += channel(i, e)
                }
            }
        }
        result.sendResult(items)
    }

    private fun folder(id: String, title: String, subtitle: String) = MediaBrowserCompat.MediaItem(
        MediaDescriptionCompat.Builder()
            .setMediaId(id).setTitle(title).setSubtitle(subtitle).build(),
        MediaBrowserCompat.MediaItem.FLAG_BROWSABLE
    )

    private fun channel(index: Int, e: PlaylistEntry) = MediaBrowserCompat.MediaItem(
        MediaDescriptionCompat.Builder()
            .setMediaId("c:$index").setTitle(e.title ?: e.url).setSubtitle(e.group).build(),
        MediaBrowserCompat.MediaItem.FLAG_PLAYABLE
    )

    // ---------------------------------------------------------------- reproducción

    private fun step(delta: Int) {
        if (queue.isEmpty()) return
        queuePos = (queuePos + delta).mod(queue.size)
        playCurrent()
    }

    private fun playCurrent() {
        val index = queue.getOrNull(queuePos) ?: return
        val entry = entries.getOrNull(index) ?: return
        val mp = player ?: return
        val engine = vlc ?: return
        if (!requestFocus()) return

        val media = Media(engine, Uri.parse(entry.url))
        media.addOption(":no-video")
        mp.media = media
        media.release()
        mp.play()

        val title = entry.title ?: entry.url
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, entry.group ?: "")
                .build()
        )
        setState(PlaybackStateCompat.STATE_BUFFERING)
        goForeground(title)
    }

    private fun onPlayerEvent(event: MediaPlayer.Event) {
        when (event.type) {
            MediaPlayer.Event.Playing -> setState(PlaybackStateCompat.STATE_PLAYING)
            MediaPlayer.Event.Paused -> setState(PlaybackStateCompat.STATE_PAUSED)
            MediaPlayer.Event.EndReached -> step(1)
            MediaPlayer.Event.EncounteredError -> setState(
                PlaybackStateCompat.STATE_ERROR, "No se puede reproducir este canal"
            )
        }
    }

    private fun setState(state: Int, error: String? = null) {
        val builder = PlaybackStateCompat.Builder()
            .setActions(
                PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                    PlaybackStateCompat.ACTION_STOP or PlaybackStateCompat.ACTION_PLAY_PAUSE or
                    PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                    PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                    PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID
            )
            .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f)
        if (error != null) builder.setErrorMessage(PlaybackStateCompat.ERROR_CODE_APP_ERROR, error)
        session.setPlaybackState(builder.build())
    }

    // ---------------------------------------------------------------- foco de audio

    private fun requestFocus(): Boolean {
        val request = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener { change -> main.post { onFocusChange(change) } }
            .build()
            .also { focusRequest = it }
        return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
    }

    private fun onFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.volume = 100
                if (resumeOnFocusGain) player?.play()
                resumeOnFocusGain = false
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnFocusGain = player?.isPlaying == true
                player?.pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.volume = 30
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocusGain = false
                player?.pause()
            }
        }
    }

    // ---------------------------------------------------------------- notificación

    private fun createNotificationChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Reproducción", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun goForeground(title: String) {
        try {
            ContextCompat.startForegroundService(this, Intent(this, CarService::class.java))
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(getString(R.string.app_name))
                .setContentIntent(open)
                .setOngoing(true)
                .setStyle(MediaStyle().setMediaSession(session.sessionToken))
                .build()
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } catch (_: Exception) {
            // Sin notificación el audio sigue sonando mientras Android Auto esté conectado.
        }
    }

    private companion object {
        const val ROOT = "root"
        const val NO_GROUP = "Sin grupo"
        const val CHANNEL_ID = "playback"
        const val NOTIFICATION_ID = 1
    }
}
