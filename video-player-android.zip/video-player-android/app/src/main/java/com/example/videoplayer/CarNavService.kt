package com.example.videoplayer

import android.content.Intent
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SessionInfo
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Vídeo en Android Auto con la Car App Library (categoría navegación): Android Auto entrega una
 * superficie en la pantalla del coche y libVLC dibuja el vídeo en ella. Los botones de la barra
 * permiten cambiar de canal. Requiere "Fuentes desconocidas" en los ajustes de desarrollador.
 */
class CarNavService : CarAppService() {

    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(sessionInfo: SessionInfo): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen = VideoScreen(carContext)
    }
}

private fun icon(ctx: CarContext, res: Int) =
    CarIcon.Builder(IconCompat.createWithResource(ctx, res)).build()

/** Pantalla principal: el vídeo ocupa todo y la barra de acciones controla la reproducción. */
private class VideoScreen(ctx: CarContext) : Screen(ctx), SurfaceCallback {

    val entries = ChannelStore.load(ctx)
    val player = CarPlayer(ctx, entries) { invalidate() }

    init {
        ctx.getCarService(AppManager::class.java).setSurfaceCallback(this)
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) = player.release()
        })
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        val s = surfaceContainer.surface ?: return
        player.attachSurface(s, surfaceContainer.width, surfaceContainer.height)
    }

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) = player.detachSurface()

    fun play(index: Int, queue: List<Int>) {
        player.queue = queue
        player.play(index)
        player.title()?.let { CarToast.makeText(carContext, it, CarToast.LENGTH_SHORT).show() }
    }

    override fun onGetTemplate(): Template {
        val c = carContext
        fun action(res: Int, click: () -> Unit) =
            Action.Builder().setIcon(icon(c, res)).setOnClickListener { click() }.build()

        val strip = ActionStrip.Builder()
            .addAction(action(R.drawable.ic_list) { screenManager.push(RootListScreen(c, this)) })
            .addAction(action(R.drawable.ic_prev) { player.step(-1); toast() })
            .addAction(action(R.drawable.ic_play_pause) { player.togglePlay() })
            .addAction(action(R.drawable.ic_next) { player.step(1); toast() })
            .build()
        return NavigationTemplate.Builder().setActionStrip(strip).build()
    }

    private fun toast() {
        player.title()?.let { CarToast.makeText(carContext, it, CarToast.LENGTH_SHORT).show() }
    }
}

/** Elemento de una lista paginada. */
private class Item(val title: String, val subtitle: String? = null, val onClick: () -> Unit)

/** Lista con páginas, porque Android Auto limita las filas que se pueden mostrar. */
private open class PagedScreen(
    ctx: CarContext,
    private val title: String,
    private val items: List<Item>
) : Screen(ctx) {

    private var page = 0
    private val pageSize: Int = try {
        val limit = ctx.getCarService(ConstraintManager::class.java)
            .getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST)
        (limit - 2).coerceIn(3, 40)
    } catch (e: Exception) {
        4
    }

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
        val from = page * pageSize
        items.drop(from).take(pageSize).forEach { item ->
            val row = Row.Builder().setTitle(item.title)
            item.subtitle?.let { row.addText(it) }
            list.addItem(row.setOnClickListener { item.onClick() }.build())
        }
        if (page > 0) {
            list.addItem(Row.Builder().setTitle("◀ Anteriores")
                .setOnClickListener { page--; invalidate() }.build())
        }
        if (from + pageSize < items.size) {
            val pages = (items.size + pageSize - 1) / pageSize
            list.addItem(Row.Builder().setTitle("Siguientes ▶").addText("Página ${page + 1} de $pages")
                .setOnClickListener { page++; invalidate() }.build())
        }
        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle(title)
            .setHeaderAction(Action.BACK)
            .build()
    }
}

private class RootListScreen(ctx: CarContext, video: VideoScreen) : PagedScreen(
    ctx, "Canales",
    video.entries.let { all ->
        val tv = all.count { !it.isRadio }
        val radio = all.count { it.isRadio }
        buildList {
            if (tv > 0) add(Item("Televisión", "$tv canales") {
                video.screenManager.push(GroupsScreen(ctx, video, false))
            })
            if (radio > 0) add(Item("Radio", "$radio emisoras") {
                video.screenManager.push(GroupsScreen(ctx, video, true))
            })
        }
    }
)

private class GroupsScreen(ctx: CarContext, video: VideoScreen, radio: Boolean) : PagedScreen(
    ctx, if (radio) "Radio" else "Televisión",
    video.entries.indices
        .filter { video.entries[it].isRadio == radio }
        .groupBy { video.entries[it].group ?: "Sin grupo" }
        .map { (group, idx) ->
            Item(group, "${idx.size}") {
                video.screenManager.push(ChannelsScreen(ctx, video, group, idx))
            }
        }
)

private class ChannelsScreen(ctx: CarContext, video: VideoScreen, group: String, idx: List<Int>) : PagedScreen(
    ctx, group,
    idx.map { i ->
        val e = video.entries[i]
        Item(e.title?.takeIf { it.isNotBlank() } ?: e.url) {
            video.play(i, idx)
            video.screenManager.popToRoot()
        }
    }
)
