package com.example.videoplayer

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileNotFoundException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.json.JSONObject

/**
 * Busca la última versión publicada en GitHub Releases (etiqueta "build-N"),
 * la descarga y lanza el instalador de Android.
 */
class Updater(private val activity: AppCompatActivity) {

    fun check() {
        toast("Buscando actualizaciones…")
        thread {
            try {
                val json = JSONObject(httpGetText(API_LATEST))
                val latest = json.getString("tag_name").substringAfterLast('-').toInt()
                var apkUrl: String? = null
                val assets = json.getJSONArray("assets")
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.getString("name").endsWith(".apk")) {
                        apkUrl = asset.getString("browser_download_url")
                        break
                    }
                }
                val current = BuildConfig.VERSION_CODE
                activity.runOnUiThread {
                    when {
                        apkUrl == null -> toast("La versión $latest no incluye ninguna APK")
                        latest <= current -> toast("Ya tienes la última versión ($current)")
                        else -> AlertDialog.Builder(activity)
                            .setTitle("Nueva versión")
                            .setMessage("Hay una versión nueva ($latest). Tienes la $current.\n¿Descargar e instalar?")
                            .setPositiveButton("Actualizar") { _, _ -> download(apkUrl) }
                            .setNegativeButton(android.R.string.cancel, null)
                            .show()
                    }
                }
            } catch (e: FileNotFoundException) {
                toast("No hay versiones publicadas o el repositorio es privado")
            } catch (e: Exception) {
                toast("No se pudo comprobar: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun download(url: String) {
        toast("Descargando…")
        thread {
            try {
                val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
                val file = File(dir, "update.apk")
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    setRequestProperty("User-Agent", "VideoPlayer-Updater")
                }
                connection.inputStream.use { input ->
                    file.outputStream().use { output -> input.copyTo(output) }
                }
                activity.runOnUiThread { install(file) }
            } catch (e: Exception) {
                toast("Error al descargar: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun install(file: File) {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            toast("Permite instalar desde esta app y vuelve a pulsar Actualizar")
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    }

    private fun httpGetText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "VideoPlayer-Updater")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun toast(message: String) = activity.runOnUiThread {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
    }

    private companion object {
        const val API_LATEST =
            "https://api.github.com/repos/oldestmanmusic-sudo/video-player-android/releases/latest"
    }
}
