package com.example.videoplayer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import androidx.core.content.ContextCompat
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileNotFoundException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.json.JSONObject

/**
 * Busca la última versión publicada en GitHub Releases (etiqueta "build-N"),
 * la descarga y lanza el instalador de Android.
 */
class Updater(private val activity: AppCompatActivity) {

    fun check() {
        toast("Buscando actualizaciones…")
        thread {
            try {
                val json = JSONObject(httpGetText(API_LATEST))
                val latest = json.getString("tag_name").substringAfterLast('-').toInt()
                var apkUrl: String? = null
                val assets = json.getJSONArray("assets")
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.getString("name").endsWith(".apk")) {
                        apkUrl = asset.getString("browser_download_url")
                        break
                    }
                }
                val current = BuildConfig.VERSION_CODE
                activity.runOnUiThread {
                    when {
                        apkUrl == null -> toast("La versión $latest no incluye ninguna APK")
                        latest <= current -> toast("Ya tienes la última versión ($current)")
                        else -> AlertDialog.Builder(activity)
                            .setTitle("Nueva versión")
                            .setMessage("Hay una versión nueva ($latest). Tienes la $current.\n¿Descargar e instalar?")
                            .setPositiveButton("Actualizar") { _, _ -> download(apkUrl) }
                            .setNegativeButton(android.R.string.cancel, null)
                            .show()
                    }
                }
            } catch (e: FileNotFoundException) {
                toast("No hay versiones publicadas o el repositorio es privado")
            } catch (e: Exception) {
                toast("No se pudo comprobar: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun download(url: String) {
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Descargando actualización")
            .setMessage("0 %")
            .setCancelable(false)
            .create()
        dialog.show()
        thread {
            try {
                val dir = File(activity.cacheDir, "updates").apply { mkdirs() }
                val file = File(dir, "update.apk")
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "VideoPlayer-Updater")
                }
                val total = connection.contentLengthLong
                var done = 0L
                var lastPct = -1
                connection.inputStream.use { input ->
                    file.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    activity.runOnUiThread { dialog.setMessage("$pct %") }
                                }
                            }
                        }
                    }
                }
                activity.runOnUiThread {
                    dialog.dismiss()
                    install(file)
                }
            } catch (e: Exception) {
                activity.runOnUiThread { dialog.dismiss() }
                toast("Error al descargar: ${e.message ?: e.javaClass.simpleName}")
                openReleasePage()
            }
        }
    }

    private fun install(file: File) {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            toast("Permite instalar desde esta app y vuelve a pulsar Actualizar")
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            )
            return
        }
        try {
            installWithSession(file)
        } catch (e: Exception) {
            toast("Instalador: ${e.message ?: e.javaClass.simpleName}")
            try {
                val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
                activity.startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e2: Exception) {
                openReleasePage()
            }
        }
    }

    /** Instala con PackageInstaller: Android muestra su pantalla de confirmación. */
    private fun installWithSession(file: File) {
        val app = activity.applicationContext
        val installer = app.packageManager.packageInstaller
        val action = "${app.packageName}.INSTALL_RESULT"
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
                    PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                        @Suppress("DEPRECATION")
                        val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                        confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (confirm != null) context.startActivity(confirm)
                    }
                    PackageInstaller.STATUS_SUCCESS -> context.unregisterReceiver(this)
                    else -> {
                        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                        Toast.makeText(context, "No se instaló: $msg", Toast.LENGTH_LONG).show()
                        context.unregisterReceiver(this)
                    }
                }
            }
        }
        ContextCompat.registerReceiver(app, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)

        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            file.inputStream().use { input ->
                session.openWrite("update.apk", 0, file.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val pending = PendingIntent.getBroadcast(
                app, id, Intent(action).setPackage(app.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            session.commit(pending.intentSender)
        }
        toast("Instalando… confirma en la pantalla de Android")
    }

    private fun openReleasePage() {
        try {
            activity.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(RELEASES_PAGE)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    private fun httpGetText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "VideoPlayer-Updater")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun toast(message: String) = activity.runOnUiThread {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
    }

    private companion object {
        const val RELEASES_PAGE =
            "https://github.com/oldestmanmusic-sudo/video-player-android/releases/latest"
        const val API_LATEST =
            "https://api.github.com/repos/oldestmanmusic-sudo/video-player-android/releases/latest"
    }
}
