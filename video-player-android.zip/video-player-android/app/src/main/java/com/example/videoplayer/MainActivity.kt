package com.example.videoplayer

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.videoplayer.databinding.ActivityMainBinding
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fd: ParcelFileDescriptor? = null

    private var entries: List<PlaylistEntry> = emptyList()
    private var index = 0
    private var resumeMs = 0L
    private var pendingSeekMs = 0L
    private var seeking = false

    private val channelAdapter = ChannelAdapter { i ->
        binding.channelPanel.visibility = View.GONE
        playIndex(i)
    }

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) open(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.openFile.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        binding.openUrl.setOnClickListener { askForUrl() }
        binding.prev.setOnClickListener { playIndex(index - 1) }
        binding.next.setOnClickListener { playIndex(index + 1) }
        binding.playPause.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        binding.audio.setOnClickListener { chooseTrack(audio = true) }
        binding.subtitles.setOnClickListener { chooseTrack(audio = false) }
        binding.videoLayout.setOnClickListener { toggleControls() }

        binding.channelList.layoutManager = LinearLayoutManager(this)
        binding.channelList.adapter = channelAdapter
        binding.channels.setOnClickListener { toggleChannelPanel() }
        binding.update.text = getString(R.string.update) + " (v${BuildConfig.VERSION_CODE})"
        binding.update.setOnClickListener { Updater(this).check() }
        binding.search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                channelAdapter.filter(s?.toString().orEmpty())
            }
        })
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.channelPanel.visibility == View.VISIBLE) {
                    binding.channelPanel.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        binding.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) player?.position = progress / 1000f
            }

            override fun onStartTrackingTouch(bar: SeekBar) {
                seeking = true
            }

            override fun onStopTrackingTouch(bar: SeekBar) {
                seeking = false
            }
        })
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
    }

    override fun onStop() {
        stopPlayer()
        super.onStop()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { open(it) }
        }
    }

    // ---------------------------------------------------------------- reproductor

    private fun startPlayer() {
        if (player != null) return
        val vlc = LibVLC(this, arrayListOf("--network-caching=1500"))
        val mp = MediaPlayer(vlc)
        mp.attachViews(binding.videoLayout, null, false, false)
        mp.setEventListener { event -> runOnUiThread { onPlayerEvent(event) } }
        libVlc = vlc
        player = mp
        if (entries.isNotEmpty()) playIndex(index, resumeMs)
    }

    private fun stopPlayer() {
        player?.let {
            resumeMs = it.time.coerceAtLeast(0L)
            it.stop()
            it.detachViews()
            it.release()
        }
        libVlc?.release()
        player = null
        libVlc = null
        fd?.close()
        fd = null
    }

    private fun setEntries(newEntries: List<PlaylistEntry>) {
        if (newEntries.isEmpty()) {
            toast(R.string.empty_playlist)
            return
        }
        entries = newEntries
        index = 0
        resumeMs = 0L
        channelAdapter.submit(newEntries)
        binding.search.setText("")
        binding.channels.visibility = if (newEntries.size > 1) View.VISIBLE else View.GONE
        binding.channelPanel.visibility = View.GONE
        if (player != null) playIndex(0)
    }

    private fun playIndex(i: Int, startMs: Long = 0L) {
        val mp = player ?: return
        val vlc = libVlc ?: return
        if (i !in entries.indices) return
        index = i
        val entry = entries[i]
        val oldFd = fd
        val media = try {
            buildMedia(vlc, entry.url)
        } catch (e: Exception) {
            toast(R.string.read_error)
            return
        }
        mp.media = media
        media.release()
        if (oldFd != null && oldFd !== fd) oldFd.close()
        pendingSeekMs = startMs
        mp.play()
        binding.title.text = entry.title ?: Uri.parse(entry.url).lastPathSegment ?: entry.url
        channelAdapter.setCurrent(i)
    }

    private fun toggleChannelPanel() {
        val show = binding.channelPanel.visibility != View.VISIBLE
        binding.channelPanel.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            val pos = channelAdapter.positionOf(index)
            if (pos >= 0) binding.channelList.scrollToPosition(pos)
        }
    }

    private fun buildMedia(vlc: LibVLC, url: String): Media {
        val uri = Uri.parse(url)
        return when (uri.scheme) {
            null -> {
                fd = null
                Media(vlc, Uri.fromFile(File(url)))
            }
            "content" -> {
                val descriptor = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IllegalStateException("No se pudo abrir $url")
                fd = descriptor
                Media(vlc, descriptor.fileDescriptor)
            }
            else -> {
                fd = null
                Media(vlc, uri)
            }
        }
    }

    private fun onPlayerEvent(event: MediaPlayer.Event) {
        when (event.type) {
            MediaPlayer.Event.Playing -> {
                if (pendingSeekMs > 0L) {
                    player?.time = pendingSeekMs
                    pendingSeekMs = 0L
                }
                binding.playPause.text = "⏸"
            }
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped ->
                binding.playPause.text = "▶"
            MediaPlayer.Event.EndReached -> {
                if (index + 1 < entries.size) playIndex(index + 1)
                else binding.playPause.text = "▶"
            }
            MediaPlayer.Event.EncounteredError -> toast(R.string.play_error)
            MediaPlayer.Event.TimeChanged, MediaPlayer.Event.LengthChanged -> updateProgress()
        }
    }

    private fun updateProgress() {
        val mp = player ?: return
        val length = mp.length
        val time = mp.time
        binding.timeLabel.text = "${format(time)} / ${format(length)}"
        if (!seeking && length > 0) {
            binding.seek.progress = (time * 1000 / length).toInt()
        }
    }

    private fun format(ms: Long): String {
        val total = ms.coerceAtLeast(0L) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    private fun toggleControls() {
        val visibility =
            if (binding.topBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        binding.topBar.visibility = visibility
        binding.bottomBar.visibility = visibility
        binding.channelPanel.visibility = View.GONE
    }

    private fun chooseTrack(audio: Boolean) {
        val mp = player ?: return
        val tracks = if (audio) mp.audioTracks else mp.spuTracks
        if (tracks.isNullOrEmpty()) {
            toast(R.string.no_tracks)
            return
        }
        val names = tracks.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (audio) R.string.audio else R.string.subtitles)
            .setItems(names) { _, which ->
                val id = tracks[which].id
                if (audio) mp.setAudioTrack(id) else mp.setSpuTrack(id)
            }
            .show()
    }

    // ---------------------------------------------------------------- apertura

    /** Abre un vídeo suelto o una lista (m3u, m3u8, pls), detectándola por su contenido. */
    private fun open(uri: Uri) {
        val name = displayName(uri)
        val single = listOf(PlaylistEntry(uri.toString(), name))
        val readable = uri.scheme in listOf("http", "https", "content", "file")
        if (!readable) {
            // rtsp://, rtmp://, udp://... los gestiona VLC directamente.
            setEntries(single)
            return
        }

        thread {
            var failure: String? = null
            var result: List<PlaylistEntry>? = null
            try {
                val head = readHead(uri).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
                val byHeader = head.startsWith("#EXTM3U", ignoreCase = true) ||
                    head.startsWith("[playlist]", ignoreCase = true)
                val byName = PLAYLIST_EXTENSIONS.any { name.lowercase().endsWith(it) }
                result = if (byHeader || byName) {
                    val text = readText(uri)
                    // Un .m3u8 remoto con etiquetas #EXT-X- es un flujo HLS, no una lista.
                    if (isRemote(uri) && text.contains("#EXT-X-")) single
                    else PlaylistParser.parse(text, uri)
                } else {
                    single
                }
            } catch (e: Exception) {
                failure = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                val list = result
                if (list != null) {
                    setEntries(list)
                } else {
                    Toast.makeText(
                        this,
                        getString(R.string.read_error) + ": " + failure,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getString(0)
                            if (!n.isNullOrBlank()) return n
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    /** Abre el archivo local o la URL (siguiendo redirecciones, incluso de http a https). */
    private fun openStream(uri: Uri): InputStream {
        if (!isRemote(uri)) return requireNotNull(contentResolver.openInputStream(uri))
        var url = URL(uri.toString())
        repeat(6) {
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
            val code = c.responseCode
            if (code in 300..399) {
                val location = c.getHeaderField("Location")
                    ?: throw IOException("Redirección sin destino")
                url = URL(url, location)
                c.disconnect()
                return@repeat
            }
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream
        }
        throw IOException("Demasiadas redirecciones")
    }

    private fun readHead(uri: Uri): String =
        openStream(uri).use { stream ->
            val buffer = ByteArray(2048)
            val n = stream.read(buffer)
            if (n <= 0) "" else String(buffer, 0, n, Charsets.UTF_8)
        }

    private fun readText(uri: Uri): String =
        openStream(uri).bufferedReader().use { it.readText() }

    private fun isRemote(uri: Uri) = uri.scheme == "http" || uri.scheme == "https"

    private fun askForUrl() {
        val input = EditText(this).apply {
            hint = getString(R.string.url_hint)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.open_url)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) open(Uri.parse(text))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun toast(@StringRes message: Int) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private companion object {
        val PLAYLIST_EXTENSIONS = listOf(".m3u", ".m3u8", ".pls")
    }
}
