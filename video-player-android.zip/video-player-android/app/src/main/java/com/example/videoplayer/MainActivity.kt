package com.example.videoplayer

import android.Manifest
import android.content.Intent
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.Executors
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.os.ParcelFileDescriptor
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.videoplayer.databinding.ActivityMainBinding
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fd: ParcelFileDescriptor? = null

    private var entries: List<PlaylistEntry> = emptyList()
    private var index = 0
    private var lastOpened: Uri? = null
    private val prefs by lazy { getSharedPreferences("player", Context.MODE_PRIVATE) }
    private var resumeMs = 0L
    private var pendingSeekMs = 0L
    private var seeking = false

    private val channelAdapter = ChannelAdapter { i ->
        binding.channelPanel.visibility = View.GONE
        playIndex(i)
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) open(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.openFile.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        binding.openUrl.setOnClickListener { askForUrl() }
        binding.checkChannels.setOnClickListener { checkChannels() }
        binding.prev.setOnClickListener { playIndex(index - 1) }
        binding.next.setOnClickListener { playIndex(index + 1) }
        binding.playPause.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        binding.audio.setOnClickListener { chooseTrack(audio = true) }
        binding.subtitles.setOnClickListener { chooseTrack(audio = false) }
        binding.videoLayout.setOnClickListener { toggleControls() }

        binding.channelList.layoutManager = LinearLayoutManager(this)
        binding.channelList.adapter = channelAdapter
        binding.channels.setOnClickListener { toggleChannelPanel() }
        binding.tabTv.setOnClickListener { selectKind(false) }
        binding.tabRadio.setOnClickListener { selectKind(true) }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        binding.update.text = getString(R.string.update) + " (v${BuildConfig.VERSION_CODE})"
        binding.update.setOnClickListener { Updater(this).check() }
        binding.search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                channelAdapter.filter(s?.toString().orEmpty())
            }
        })
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.channelPanel.visibility == View.VISIBLE) {
                    binding.channelPanel.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        binding.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) player?.position = progress / 1000f
            }

            override fun onStartTrackingTouch(bar: SeekBar) {
                seeking = true
            }

            override fun onStopTrackingTouch(bar: SeekBar) {
                seeking = false
            }
        })
        if (intent?.action == Intent.ACTION_VIEW) {
            handleIntent(intent)
        } else {
            restoreSaved()
        }
    }

    /** Al abrir la app: recupera la última lista guardada (y su último canal) sin pedirla otra vez. */
    private fun restoreSaved() {
        val saved = ChannelStore.loadSaved(this)
        if (saved.isEmpty()) return
        val lastUrl = prefs.getString("last_channel", null)
        setEntries(saved, keepUrl = lastUrl, save = false)
        // Actualiza la lista en segundo plano desde su enlace, si lo hay.
        prefs.getString("source_url", null)?.let { open(Uri.parse(it), silent = true) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
    }

    override fun onStop() {
        stopPlayer()
        super.onStop()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { open(it) }
        }
    }

    // ---------------------------------------------------------------- reproductor

    private fun startPlayer() {
        if (player != null) return
        val vlc = LibVLC(this, arrayListOf("--network-caching=1500"))
        val mp = MediaPlayer(vlc)
        mp.attachViews(binding.videoLayout, null, false, false)
        mp.setEventListener { event -> runOnUiThread { onPlayerEvent(event) } }
        libVlc = vlc
        player = mp
        if (entries.isNotEmpty()) playIndex(index, resumeMs)
    }

    private fun stopPlayer() {
        player?.let {
            resumeMs = it.time.coerceAtLeast(0L)
            it.stop()
            it.detachViews()
            it.release()
        }
        libVlc?.release()
        player = null
        libVlc = null
        fd?.close()
        fd = null
    }

    private fun setEntries(
        newEntries: List<PlaylistEntry>,
        keepUrl: String? = null,
        save: Boolean = true,
        replay: Boolean = true
    ) {
        if (newEntries.isEmpty()) {
            toast(R.string.empty_playlist)
            return
        }
        val keep = keepUrl?.let { u -> newEntries.indexOfFirst { it.url == u } }?.takeIf { it >= 0 }
        entries = newEntries
        index = keep ?: 0
        resumeMs = 0L
        channelAdapter.submit(newEntries)
        setupTabs()
        if (newEntries.size > 1 && save) {
            // Guardada para que Android Auto y el próximo arranque usen la última lista abierta.
            val app = applicationContext
            thread { try { ChannelStore.save(app, newEntries) } catch (_: Exception) { } }
            val src = lastOpened
            val remote = src != null && src.scheme in listOf("http", "https")
            prefs.edit().apply {
                if (remote) putString("source_url", src.toString()) else remove("source_url")
            }.apply()
        }
        if (keep != null) channelAdapter.setCurrent(keep)
        binding.search.setText("")
        binding.channels.visibility = if (newEntries.size > 1) View.VISIBLE else View.GONE
        binding.channelPanel.visibility = View.GONE
        if (player != null && replay) playIndex(keep ?: 0)
    }

    // ---------------------------------------------------------------- probar canales

    private fun withoutDead(list: List<PlaylistEntry>): List<PlaylistEntry> {
        val dead = prefs.getStringSet("dead", emptySet()).orEmpty()
        if (dead.isEmpty() || list.size <= 1) return list
        return list.filter { it.url !in dead }.ifEmpty { list }
    }

    private fun isAlive(url: String): Boolean {
        if (!url.startsWith("http")) return true
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 5_000
            c.readTimeout = 5_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
            try {
                if (c.responseCode !in 200..299) return false
                if (c.contentType?.contains("text/html", ignoreCase = true) == true) return false
                val buf = ByteArray(1024)
                val n = c.inputStream.use { it.read(buf) }
                if (n <= 0) return false
                !url.substringBefore('?').endsWith(".m3u8") || String(buf, 0, n).contains("#EXTM3U")
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Prueba cada canal desde el móvil (con tu conexión y tu país) y deja solo los que responden. */
    private fun checkChannels() {
        val list = entries
        if (list.size <= 1) return
        Toast.makeText(this, "Probando ${list.size} canales… puede tardar unos minutos", Toast.LENGTH_LONG).show()
        binding.checkChannels.isEnabled = false
        val currentUrl = list.getOrNull(index)?.url
        thread {
            val pool = Executors.newFixedThreadPool(24)
            val dead = Collections.synchronizedSet(mutableSetOf<String>())
            val done = AtomicInteger(0)
            val futures = list.map { e ->
                pool.submit {
                    if (!isAlive(e.url)) dead.add(e.url)
                    val n = done.incrementAndGet()
                    if (n % 100 == 0) runOnUiThread {
                        Toast.makeText(this, "Probados $n de ${list.size}…", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            futures.forEach { try { it.get() } catch (_: Exception) { } }
            pool.shutdown()
            val good = list.filter { it.url !in dead }
            runOnUiThread {
                binding.checkChannels.isEnabled = true
                if (good.isEmpty()) {
                    Toast.makeText(this, "No responde ningún canal: ¿hay conexión a internet?", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putStringSet("dead", dead.toSet()).apply()
                    setEntries(good, keepUrl = currentUrl, replay = false)
                    Toast.makeText(this, "Funcionan ${good.size} de ${list.size} canales", Toast.LENGTH_LONG).show()
                    binding.channelPanel.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun playIndex(i: Int, startMs: Long = 0L) {
        val mp = player ?: return
        val vlc = libVlc ?: return
        if (i !in entries.indices) return
        index = i
        val entry = entries[i]
        prefs.edit().putString("last_channel", entry.url).apply()
        val oldFd = fd
        val media = try {
            buildMedia(vlc, entry.url)
        } catch (e: Exception) {
            toast(R.string.read_error)
            return
        }
        mp.media = media
        media.release()
        if (oldFd != null && oldFd !== fd) oldFd.close()
        pendingSeekMs = startMs
        mp.play()
        binding.title.text = entry.title ?: Uri.parse(entry.url).lastPathSegment ?: entry.url
        channelAdapter.setCurrent(i)
    }

    private var selectedRadio: Boolean? = null

    /** Muestra las pestañas Televisión / Radio solo si la lista tiene de las dos. */
    private fun setupTabs() {
        val tv = channelAdapter.count(false)
        val radio = channelAdapter.count(true)
        binding.tabs.visibility = if (tv > 0 && radio > 0) View.VISIBLE else View.GONE
        binding.tabTv.text = "Televisión ($tv)"
        binding.tabRadio.text = "Radio ($radio)"
        selectKind(when {
            tv > 0 && radio > 0 -> false
            radio > 0 -> true
            else -> null
        })
    }

    private fun selectKind(isRadio: Boolean?) {
        selectedRadio = isRadio
        channelAdapter.setKind(isRadio)
        val on = android.graphics.Color.parseColor("#66B2FF")
        binding.tabTv.setTextColor(if (isRadio == false) on else android.graphics.Color.WHITE)
        binding.tabRadio.setTextColor(if (isRadio == true) on else android.graphics.Color.WHITE)
    }

    private fun toggleChannelPanel() {
        val show = binding.channelPanel.visibility != View.VISIBLE
        binding.channelPanel.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            val pos = channelAdapter.positionOf(index)
            if (pos >= 0) binding.channelList.scrollToPosition(pos)
        }
    }

    private fun buildMedia(vlc: LibVLC, url: String): Media {
        val uri = Uri.parse(url)
        return when (uri.scheme) {
            null -> {
                fd = null
                Media(vlc, Uri.fromFile(File(url)))
            }
            "content" -> {
                val descriptor = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IllegalStateException("No se pudo abrir $url")
                fd = descriptor
                Media(vlc, descriptor.fileDescriptor)
            }
            else -> {
                fd = null
                Media(vlc, uri)
            }
        }
    }

    private fun onPlayerEvent(event: MediaPlayer.Event) {
        when (event.type) {
            MediaPlayer.Event.Playing -> {
                if (pendingSeekMs > 0L) {
                    player?.time = pendingSeekMs
                    pendingSeekMs = 0L
                }
                binding.playPause.text = "⏸"
            }
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped ->
                binding.playPause.text = "▶"
            MediaPlayer.Event.EndReached -> {
                if (index + 1 < entries.size) playIndex(index + 1)
                else binding.playPause.text = "▶"
            }
            MediaPlayer.Event.EncounteredError -> toast(R.string.play_error)
            MediaPlayer.Event.TimeChanged, MediaPlayer.Event.LengthChanged -> updateProgress()
        }
    }

    private fun updateProgress() {
        val mp = player ?: return
        val length = mp.length
        val time = mp.time
        binding.timeLabel.text = "${format(time)} / ${format(length)}"
        if (!seeking && length > 0) {
            binding.seek.progress = (time * 1000 / length).toInt()
        }
    }

    private fun format(ms: Long): String {
        val total = ms.coerceAtLeast(0L) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    private fun toggleControls() {
        val visibility =
            if (binding.topBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        binding.topBar.visibility = visibility
        binding.bottomBar.visibility = visibility
        binding.channelPanel.visibility = View.GONE
    }

    private fun chooseTrack(audio: Boolean) {
        val mp = player ?: return
        val tracks = if (audio) mp.audioTracks else mp.spuTracks
        if (tracks.isNullOrEmpty()) {
            toast(R.string.no_tracks)
            return
        }
        val names = tracks.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (audio) R.string.audio else R.string.subtitles)
            .setItems(names) { _, which ->
                val id = tracks[which].id
                if (audio) mp.setAudioTrack(id) else mp.setSpuTrack(id)
            }
            .show()
    }

    // ---------------------------------------------------------------- apertura

    /** Abre un vídeo suelto o una lista (m3u, m3u8, pls), detectándola por su contenido. */
    private fun open(uri: Uri, silent: Boolean = false) {
        lastOpened = uri
        if (!silent) prefs.edit().remove("dead").apply()
        val name = displayName(uri)
        val single = listOf(PlaylistEntry(uri.toString(), name))
        val readable = uri.scheme in listOf("http", "https", "content", "file")
        if (!readable) {
            // rtsp://, rtmp://, udp://... los gestiona VLC directamente.
            setEntries(single)
            return
        }

        thread {
            var failure: String? = null
            var result: List<PlaylistEntry>? = null
            try {
                val byName = PLAYLIST_EXTENSIONS.any { name.lowercase().endsWith(it) }
                // Una sola petición: si empieza como lista se lee entera; si no, se cierra.
                val text = readIfPlaylist(uri, byName)
                result = when {
                    text == null -> single
                    // Un .m3u8 remoto con etiquetas #EXT-X- es un flujo HLS, no una lista.
                    isRemote(uri) && text.contains("#EXT-X-") -> single
                    else -> PlaylistParser.parse(text, uri)
                }
            } catch (e: Exception) {
                failure = e.message ?: e.javaClass.simpleName
                if (isRemote(uri)) {
                    // Plan B: que lea la lista el propio motor de VLC (otra pila de red).
                    try {
                        result = resolveWithVlc(uri).takeIf { it.isNotEmpty() }
                    } catch (_: Throwable) {
                    }
                }
            }
            runOnUiThread {
                val list = result
                val reason = failure
                when {
                    silent && (list == null || list.size <= 1) -> Unit
                    list != null -> setEntries(
                        withoutDead(list),
                        keepUrl = if (silent) entries.getOrNull(index)?.url else null,
                        replay = !silent
                    )
                    // Tercer intento: navegador interno (supera los filtros anti-bots tipo Cloudflare).
                    isRemote(uri) -> fetchViaWebView(uri) { text ->
                        val parsed = text?.let { PlaylistParser.parse(it, uri) }.orEmpty()
                        if (parsed.isNotEmpty()) {
                            setEntries(parsed)
                        } else {
                            Toast.makeText(
                                this,
                                getString(R.string.read_error) + ": " + reason +
                                    " (tampoco con el navegador interno)",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    else -> Toast.makeText(
                        this,
                        getString(R.string.read_error) + ": " + reason,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private inner class WebBridge(private val callback: (String) -> Unit) {
        @JavascriptInterface
        fun text(t: String) = callback(t)
    }

    /**
     * Abre la portada de la web en un WebView (que pasa la comprobación anti-bots como un
     * navegador real) y pide la lista desde esa misma página. Devuelve el texto o null.
     */
    private fun fetchViaWebView(uri: Uri, onDone: (String?) -> Unit) {
        Toast.makeText(this, "Probando con el navegador interno…", Toast.LENGTH_SHORT).show()
        val handler = Handler(Looper.getMainLooper())
        val web = WebView(this)
        var finished = false

        fun finish(text: String?) {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            web.stopLoading()
            web.destroy()
            onDone(text)
        }

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(WebBridge { t ->
            runOnUiThread {
                val head = t.trimStart('\uFEFF', ' ', '\t', '\r', '\n')
                if (head.startsWith("#EXTM3U", ignoreCase = true) ||
                    head.startsWith("[playlist]", ignoreCase = true)
                ) finish(t)
            }
        }, "Android")

        val target = JSONObject.quote(uri.toString())
        web.webViewClient = object : WebViewClient() {
            // Se dispara en cada carga (también tras superar el desafío de Cloudflare).
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(
                    "fetch($target,{credentials:'include'})" +
                        ".then(r=>r.text()).then(t=>Android.text(t))" +
                        ".catch(e=>Android.text('ERR '+e))",
                    null
                )
            }
        }
        handler.postDelayed({ finish(null) }, 30_000)
        web.loadUrl("${uri.scheme}://${uri.authority}/")
    }

    /** Pide la lista con libVLC (su propia red) y devuelve las entradas que encuentra. */
    private fun resolveWithVlc(uri: Uri): List<PlaylistEntry> {
        val vlc = LibVLC(this, arrayListOf("--network-caching=1500"))
        try {
            val media = Media(vlc, uri)
            media.parse(IMedia.Parse.ParseNetwork)
            val subs = media.subItems()
            val out = mutableListOf<PlaylistEntry>()
            for (i in 0 until subs.count) {
                val item = subs.getMediaAt(i)
                out += PlaylistEntry(item.uri.toString(), item.getMeta(IMedia.Meta.Title))
                item.release()
            }
            subs.release()
            media.release()
            return out
        } finally {
            vlc.release()
        }
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getString(0)
                            if (!n.isNullOrBlank()) return n
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    /**
     * Abre el archivo local o la URL, siguiendo redirecciones (incluso de http a https).
     * Si el servidor responde 403/406 prueba con otras identificaciones (User-Agent),
     * porque muchos servidores IPTV solo aceptan algunas.
     */
    private fun openStream(uri: Uri): InputStream {
        if (!isRemote(uri)) return requireNotNull(contentResolver.openInputStream(uri))
        var lastCode = 0
        var lastServer: String? = null
        for (agent in USER_AGENTS) {
            var url = URL(uri.toString())
            var redirects = 0
            while (true) {
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10_000
                c.readTimeout = 15_000
                c.instanceFollowRedirects = false
                if (agent != null) c.setRequestProperty("User-Agent", agent)
                c.setRequestProperty("Accept", "*/*")
                c.setRequestProperty("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
                c.setRequestProperty("Referer", "${url.protocol}://${url.host}/")
                val code = c.responseCode
                if (code in 300..399 && redirects < 6) {
                    val location = c.getHeaderField("Location")
                        ?: throw IOException("Redirección sin destino")
                    url = URL(url, location)
                    redirects++
                    c.disconnect()
                    continue
                }
                if (code in 200..299) return c.inputStream
                lastCode = code
                lastServer = c.getHeaderField("Server")
                c.disconnect()
                break
            }
            if (lastCode != 403 && lastCode != 406) break
        }
        throw IOException("HTTP $lastCode" + (lastServer?.let { " ($it)" } ?: ""))
    }

    /** Devuelve el texto completo si el recurso es una lista (m3u/pls); null si no lo es. */
    private fun readIfPlaylist(uri: Uri, byName: Boolean): String? =
        openStream(uri).use { stream ->
            val buffer = ByteArray(2048)
            var n = 0
            while (n < buffer.size) {
                val r = stream.read(buffer, n, buffer.size - n)
                if (r < 0) break
                n += r
            }
            val head = String(buffer, 0, n, Charsets.UTF_8)
                .trimStart('\uFEFF', ' ', '\t', '\r', '\n')
            val isList = byName ||
                head.startsWith("#EXTM3U", ignoreCase = true) ||
                head.startsWith("[playlist]", ignoreCase = true)
            if (!isList) null
            else String(buffer.copyOf(n) + stream.readBytes(), Charsets.UTF_8)
        }

    private fun isRemote(uri: Uri) = uri.scheme == "http" || uri.scheme == "https"

    private fun askForUrl() {
        val input = EditText(this).apply {
            hint = getString(R.string.url_hint)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.open_url)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) open(Uri.parse(text))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun toast(@StringRes message: Int) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private companion object {
        val PLAYLIST_EXTENSIONS = listOf(".m3u", ".m3u8", ".pls")
        // null = identificación por defecto de Android (la que funcionaba antes)
        val USER_AGENTS = listOf<String?>(
            null,
            "VLC/3.0.20 LibVLC/3.0.20"
        )
    }
}
