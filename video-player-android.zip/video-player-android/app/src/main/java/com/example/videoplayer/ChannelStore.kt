package com.example.videoplayer

import android.content.Context
import java.io.File

/**
 * Guarda la última lista de canales abierta en la app para que la use también Android Auto.
 * Si todavía no se ha abierto ninguna, usa la lista incluida en la app (assets/channels.m3u8).
 */
object ChannelStore {
    private const val FILE = "last_list.m3u8"
    private const val DEFAULT_ASSET = "channels.m3u8"

    fun save(context: Context, entries: List<PlaylistEntry>) {
        val sb = StringBuilder("#EXTM3U\n")
        for (e in entries) {
            sb.append("#EXTINF:-1")
            e.group?.let { sb.append(" group-title=\"").append(it.replace('"', '\'')).append('"') }
            if (e.isRadio) sb.append(" radio=\"true\"")
            sb.append(',').append((e.title ?: e.url).replace('\n', ' ')).append('\n')
            sb.append(e.url).append('\n')
        }
        File(context.filesDir, FILE).writeText(sb.toString())
    }

    /** Lista guardada por el usuario (sin la de ejemplo incluida en la app); vacía si no hay. */
    fun loadSaved(context: Context): List<PlaylistEntry> {
        val saved = File(context.filesDir, FILE)
        if (!saved.exists()) return emptyList()
        return try {
            PlaylistParser.parse(saved.readText(), null)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun load(context: Context): List<PlaylistEntry> {
        val saved = File(context.filesDir, FILE)
        val text = try {
            if (saved.exists()) saved.readText()
            else context.assets.open(DEFAULT_ASSET).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            return emptyList()
        }
        return PlaylistParser.parse(text, null)
    }
}
