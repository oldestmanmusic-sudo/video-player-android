# Video Player Android

Reproductor de vídeo para Android (Kotlin + libVLC, el motor de VLC).

## Qué hace

- Reproduce prácticamente cualquier formato y códec de vídeo y audio que reproduce VLC (MP4, MKV, AVI, WMV, FLV, WebM, TS, MOV, OGG, MP3, FLAC...).
- Abre vídeos locales (selector de archivos) o por URL.
- Admite listas **M3U / M3U8**, **PLS** y listas de URLs en texto plano, con títulos (`#EXTINF`), y pasa solo al siguiente elemento.
- Reproduce flujos **HLS**, **DASH**, **RTSP**, **RTMP** y similares.
- Controles propios: reproducir/pausa, anterior/siguiente, barra de progreso, selección de pista de audio y de subtítulos. Un toque en la pantalla oculta o muestra los controles.
- Se registra como app para abrir vídeos y listas m3u desde otras apps.
- Reanuda la posición al volver a la app.

## Compilar

1. Abre la carpeta en Android Studio (Koala o superior, JDK 17).
2. Deja que sincronice Gradle (el wrapper se genera al abrir el proyecto).
3. Ejecuta en un dispositivo o emulador ARM.

## Notas

- libVLC añade bastante peso a la app. Por eso `app/build.gradle.kts` incluye solo las arquitecturas ARM (`armeabi-v7a` y `arm64-v8a`). Para probar en un emulador x86, elimina el bloque `ndk { abiFilters ... }`.
- Si la versión `org.videolan.android:libvlc-all:3.6.0` no se resuelve, consulta la última disponible en Maven Central.
- Las rutas relativas dentro de una lista m3u **local** no se resuelven; solo las de listas remotas.
- Se permite tráfico http sin cifrar porque muchas listas IPTV lo usan.
- libVLC se distribuye bajo LGPL: revisa sus condiciones si publicas la app.
